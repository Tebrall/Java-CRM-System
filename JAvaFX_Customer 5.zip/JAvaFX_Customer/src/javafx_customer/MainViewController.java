package javafx_customer;

/**
 Created by Teimur Bairamaliev;
 Student ID 34684126;
 Date: 3.04.2024;
 JAVA FILE's included in this project:
 *MainViewController.java
 *Customer.java
 *PayingCustomer.java
 *AssociateCustomer.java
 *Supplement.java
 *PaymentMethod.java
 *Customer_Address.java
 *MagazineServiceApp.java
 DESCRIPTION OF THE  PROJECT:
 "a program to manage an online weekly personalized magazine service.";
 */

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.util.StringConverter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class MainViewController {
    @FXML private ListView<Supplement> supplementsList;
    @FXML private ListView<Customer> customersList;
    @FXML private TextArea infoPanel;
    @FXML private Button billingInfoButton;
    @FXML private TextField emailField; 
    @FXML private TextField streetNumberField;
    @FXML private ComboBox<String> customerTypeBox;
    @FXML private Button editInfoButton;
    @FXML private Button saveDataButton;



    private Customer selectedCustomer;
    private Magazine magazine;
    
private ComboBox<PayingCustomer> payingCustomerBox;


    public void setMagazine(Magazine magazine) {
        this.magazine = magazine;
    }
    
    @FXML
private void handleSaveDataAction(ActionEvent event) {
    saveDataToCSV();
}


private void saveDataToCSV() {
    // Create a new File object for 'magazine_data.csv' where the data will be saved.
    File file = new File("magazine_data.csv");
    
    // Try-with-resources statement to automatically close the PrintWriter.
    try (PrintWriter writer = new PrintWriter(file)) {
        // Write the CSV header line.
        writer.println("Type,Name,Email,Address,Payment Details,Supplements");

        // Iterate over each customer in the magazine's customer list.
        for (Customer customer : magazine.getCustomers()) {
            // Collect the names of all supplements subscribed by the customer into a list.
            List<String> supplements = customer.getSupplementsList().stream()
                .map(Supplement::getName)
                .collect(Collectors.toList());
            
            // Determine the customer type based on whether the customer instance is of PayingCustomer class.
            String customerType = customer instanceof PayingCustomer ? "Paying" : "Associate";
            
            // Retrieve payment details if the customer is a paying one; otherwise, leave it blank.
            String paymentDetails = customer instanceof PayingCustomer ?
                ((PayingCustomer) customer).getPaymentMethod().toString() : "";

            // Format customer data into a single line, adhering to CSV format. Addresses and supplements are enclosed in quotes to handle commas within.
            String line = String.format("%s,%s,%s,\"%s\",%s,\"%s\"",
                    customerType,
                    customer.getName(),
                    customer.getEmail(),
                    customer.getAddress(),
                    paymentDetails,
                    String.join(" | ", supplements));
            // Write the formatted line to the CSV file.
            writer.println(line);
        }
        
        // Flush the writer to ensure all data is written to the file.
        writer.flush();
        
        // Show a success alert to the user, indicating where the data was saved.
        showAlert("Data Saved", "The data has been successfully saved to " + file.getAbsolutePath());
    } catch (FileNotFoundException e) {
        // Show an error alert if the file could not be created or opened.
        showAlert("Error", "Failed to save data: " + e.getMessage());
    }
} 



  
@FXML
private void handleEditInfoAction() {
    Customer selected = customersList.getSelectionModel().getSelectedItem();
    if (selected != null) {
        editCustomerInfo(selected);
    } else if (supplementsList.getSelectionModel().getSelectedItem() != null) {
        editSupplementInfo(supplementsList.getSelectionModel().getSelectedItem());
    }
}

@FXML
private void editCustomerInfo(Customer customer) {
   
    if (customer == null) {
        return; // if No customer selected, so user cannot edit
    }
    boolean isEditing = customer != null;

    Dialog<Customer> dialog = new Dialog<>();
    dialog.setTitle(isEditing ? "Edit Customer Info" : "Add New Customer");
    GridPane grid = new GridPane();
    grid.setHgap(10);
    grid.setVgap(10);

    TextField nameField = new TextField(isEditing ? customer.getName() : "");
    nameField.setPromptText("Name");
    TextField emailField = new TextField(isEditing ? customer.getEmail() : "");
    emailField.setPromptText("Email");
    TextField streetNameField = new TextField(isEditing ? customer.getAddress().getStreetName() : "");
    streetNameField.setPromptText("Street Name");
    TextField streetNumberField = new TextField(isEditing ? String.valueOf(customer.getAddress().getStreetNumber()) : "");
    streetNumberField.setPromptText("Street Number");
    TextField suburbField = new TextField(isEditing ? customer.getAddress().getSuburb() : "");
    suburbField.setPromptText("Suburb");
    TextField postcodeField = new TextField(isEditing ? customer.getAddress().getPostcode() : "");
    postcodeField.setPromptText("Postcode");
    ComboBox<String> customerTypeBox = new ComboBox<>();
    customerTypeBox.getItems().addAll("Paying", "Associate");

    ListView<Supplement> supplementsListView = new ListView<>();
    supplementsListView.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
    supplementsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    if (isEditing) {
        customer.getSupplementsList().forEach(supplement -> {
            supplementsListView.getSelectionModel().select(supplement);
        });
    }

    customerTypeBox.setValue(customer instanceof PayingCustomer ? "Paying" : "Associate");
    ComboBox<PaymentMethod.MethodType> paymentMethodBox = new ComboBox<>(FXCollections.observableArrayList(PaymentMethod.MethodType.values()));
    TextField cardNumberField = new TextField();
    cardNumberField.setPromptText("Card Number");

    if (customer instanceof PayingCustomer) {
        paymentMethodBox.setValue(((PayingCustomer) customer).getPaymentMethod().getMethodType());
        cardNumberField.setText(((PayingCustomer) customer).getPaymentMethod().getDetails());
    }

    grid.add(new Label("Name:"), 0, 0);
    grid.add(nameField, 1, 0);
    grid.add(new Label("Email:"), 0, 1);
    grid.add(emailField, 1, 1);
    grid.add(new Label("Street Name:"), 0, 2);
    grid.add(streetNameField, 1, 2);
    grid.add(new Label("Street Number:"), 0, 3);
    grid.add(streetNumberField, 1, 3);
    grid.add(new Label("Suburb:"), 0, 4);
    grid.add(suburbField, 1, 4);
    grid.add(new Label("Postcode:"), 0, 5);
    grid.add(postcodeField, 1, 5);
    grid.add(new Label("Customer Type:"), 0, 6);
    grid.add(customerTypeBox, 1, 6);
    grid.add(new Label("Payment Method:"), 0, 7);
    grid.add(paymentMethodBox, 1, 7);
    grid.add(new Label("Card Number:"), 0, 8);
    grid.add(cardNumberField, 1, 8);
    grid.add(new Label("Supplements:"), 0, 9);
    grid.add(supplementsListView, 1, 9);

    dialog.getDialogPane().setContent(grid);
    ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
    dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

    dialog.setResultConverter(dialogButton -> {
        if (dialogButton == saveButtonType) {
            customer.setName(nameField.getText());
            customer.setEmail(emailField.getText());
            customer.setAddress(new Customer_Address(Integer.parseInt(streetNumberField.getText()), streetNameField.getText(), suburbField.getText(), postcodeField.getText()));
            customer.getSupplementsList().clear();
            customer.getSupplementsList().addAll(supplementsListView.getSelectionModel().getSelectedItems());
            if (customer instanceof PayingCustomer && "Paying".equals(customerTypeBox.getValue())) {
                ((PayingCustomer) customer).setPaymentMethod(new PaymentMethod(paymentMethodBox.getValue(), cardNumberField.getText()));
            }
            return customer;
        }
        return null;
    });

    Optional<Customer> result = dialog.showAndWait();
    result.ifPresent(newCustomer -> {
        updateCustomerListView();
    });
}


private void editSupplementInfo(Supplement supplement) {
    
}

  @FXML
private void handleDefaultView(ActionEvent event) {
    // Reset the magazine with default data for view mode
    initializeDefaultMagazineData();
    

    updateCustomerListView();
    updateSupplementsListView();
    infoPanel.clear(); 
    
    
    infoPanel.setText("Default view restored. All changes have been reset.");
}


private void initializeDefaultMagazineData() {
    magazine.getSupplements().clear();
    magazine.getCustomers().clear();
    // Add supplements
    magazine.addSupplement(new Supplement("Luxury Homes", 5));
    magazine.addSupplement(new Supplement("Exotic Cars", 3));
    magazine.addSupplement(new Supplement("Jewelry Queen", 4));

    // Add customers
    Customer_Address address1 = new Customer_Address(123, "Main Street", "Suburbia", "12345");
    Customer_Address address2 = new Customer_Address(456, "Second Street", "Downtown", "67890");
    Customer_Address address3 = new Customer_Address(789, "Third Avenue", "Uptown", "10112");

    PayingCustomer payingCustomer1 = new PayingCustomer("Kamran", "Kamran@gmail.com", new PaymentMethod(PaymentMethod.MethodType.CREDIT_CARD, "1234-5678-9012-3456"), address1);
    payingCustomer1.addSupplement(magazine.getSupplements().get(0));

    AssociateCustomer associateCustomer1 = new AssociateCustomer("Jaman", "Jaman@outlook.com", payingCustomer1, address3);
    associateCustomer1.addSupplement(magazine.getSupplements().get(1));

    PayingCustomer payingCustomer2 = new PayingCustomer("Emin", "Emin777@mail.ru", new PaymentMethod(PaymentMethod.MethodType.DIRECT_DEBIT, "9876-5432-1098-7654"), address2);
    payingCustomer2.addSupplement(magazine.getSupplements().get(2));

    magazine.addCustomer(payingCustomer1);
    magazine.addCustomer(associateCustomer1);
    magazine.addCustomer(payingCustomer2);
}
    private void updateSupplementsListView() {
        supplementsList.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
        supplementsList.refresh();
    }
    private boolean validateCustomerInputs(TextField nameField, TextField emailField, TextField streetNumberField, TextField postcodeField, ComboBox<String> customerTypeBox, ComboBox<String> paymentMethodBox, TextField cardNumberField) {
    StringBuilder errorMessage = new StringBuilder();
    boolean isValid = true;

    // Validate name
    if (nameField.getText().trim().isEmpty()) {
        errorMessage.append("Name cannot be empty.\n");
        isValid = false;
    }

    // Validate email (You already have a method for this)
    if (!emailField.getText().contains("@")) {
        errorMessage.append("Email is invalid.\n");
        isValid = false;
    }

    // Validate street number as a number
    try {
        Integer.parseInt(streetNumberField.getText());
    } catch (NumberFormatException e) {
        errorMessage.append("Street Number must be a valid number.\n");
        isValid = false;
    }

    // Optional: You can add more validations here as needed, such as checking if the postcode is empty or if the payment method is selected for paying customers

    // Show an alert if there are validation errors
    if (!isValid) {
        showAlert("Invalid Input", errorMessage.toString());
    }

    return isValid;
}
        @FXML
    private void handleAddCustomer() {
        ListView<Supplement> dialogSupplementsList = new ListView<>();
        dialogSupplementsList.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
        dialogSupplementsList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        dialogSupplementsList.setPrefHeight(50);

        dialogSupplementsList.setCellFactory(lv -> new ListCell<Supplement>() {
             @Override
             protected void updateItem(Supplement item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getName());
            }
        }   );


    ObservableList<Customer> payingCustomers = magazine.getCustomers().stream()
        .filter(c -> c instanceof PayingCustomer)
        .collect(Collectors.toCollection(FXCollections::observableArrayList));

     ComboBox<Customer> payingCustomerBox = new ComboBox<>(payingCustomers);
     payingCustomerBox.setConverter(new StringConverter<Customer>() {
      @Override
      public String toString(Customer customer) {
         return customer != null ? customer.getName() : "";
     }

    @Override
    public Customer fromString(String string) {
        return null; 
       }
    });
        payingCustomerBox.setDisable(true); // Initially disable, enable when Associate is selected

    Dialog<Customer> dialog = new Dialog<>();
    dialog.setTitle("Add New Customer");
    dialog.setHeaderText("Fill in the details for the new customer:");
    
    GridPane grid = new GridPane();
    grid.setHgap(10);
    grid.setVgap(10);

    TextField nameField = new TextField();
    nameField.setPromptText("Name");
    
    TextField emailField = new TextField();
    emailField.setPromptText("Email");
    
    TextField streetNameField = new TextField();
    streetNameField.setPromptText("Street Name");
    
    TextField streetNumberField = new TextField();
    streetNumberField.setPromptText("Street Number");
    
    TextField suburbField = new TextField();
    suburbField.setPromptText("Suburb");
    
    TextField postcodeField = new TextField();
    postcodeField.setPromptText("Postcode");
    
    ComboBox<String> customerTypeBox = new ComboBox<>();
    customerTypeBox.getItems().addAll("Paying", "Associate");
    
    ComboBox<String> paymentMethodBox = new ComboBox<>();
    grid.add(new Label("Paying Customer:"), 0, 11); // Adjust the row index as needed
    grid.add(payingCustomerBox, 1, 11);
    paymentMethodBox.getItems().addAll("CREDIT_CARD", "DIRECT_DEBIT");
    paymentMethodBox.setDisable(true);
    TextField cardNumberField = new TextField();
    cardNumberField.setPromptText("Card Number");
    cardNumberField.setDisable(true);
    ListView<Supplement> supplementsListView = new ListView<>();
    supplementsListView.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
    supplementsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    ComboBox<PayingCustomer> payingCustomersBox = new ComboBox<>();
    payingCustomersBox.getItems().addAll(magazine.getPayingCustomers()); 
    payingCustomersBox.setDisable(true);



    //Added logic to enable this box only for associate customers
    customerTypeBox.valueProperty().addListener((obs, oldVal, newVal) -> {
        boolean isAssociate = "Associate".equals(newVal);
        payingCustomersBox.setDisable(!isAssociate);
    });


        customerTypeBox.valueProperty().addListener((obs, oldVal, newVal) -> {
        boolean isPaying = "Paying".equals(newVal);
        paymentMethodBox.setDisable(!isPaying);
        cardNumberField.setDisable(!isPaying);
        payingCustomerBox.setDisable(!"Associate".equals(newVal)); // Only enable for Associate type
    });



    grid.add(new Label("Name:"), 0, 0);
    grid.add(nameField, 1, 0);
    grid.add(new Label("Email:"), 0, 1);
    grid.add(emailField, 1, 1);
    grid.add(new Label("Street Name:"), 0, 2);
    grid.add(streetNameField, 1, 2);
    grid.add(new Label("Street Number:"), 0, 3);
    grid.add(streetNumberField, 1, 3);
    grid.add(new Label("Suburb:"), 0, 4);
    grid.add(suburbField, 1, 4);
    grid.add(new Label("Postcode:"), 0, 5);
    grid.add(postcodeField, 1, 5);
    grid.add(new Label("Customer Type:"), 0, 6);
    grid.add(customerTypeBox, 1, 6);
    grid.add(new Label("Payment Method:"), 0, 7);
    grid.add(paymentMethodBox, 1, 7);
    grid.add(new Label("Card Number:"), 0, 8);
    grid.add(cardNumberField, 1, 8);
    grid.add(new Label("Supplements:"), 0, 10); 
    grid.add(dialogSupplementsList, 1, 10); 

    
       ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
    dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
    
    
    Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
saveButton.addEventFilter(ActionEvent.ACTION, event -> {
    // Validate inputs
    if (!validateCustomerInputs(nameField, emailField, streetNumberField, postcodeField, customerTypeBox, paymentMethodBox, cardNumberField)) { 
        event.consume(); // Preventing the dialog from closing if validation fails
    }
});



    dialog.getDialogPane().setContent(grid);
    Platform.runLater(nameField::requestFocus);
    
    

    dialog.setResultConverter(dialogButton -> {
       
        
    
        if (dialogButton == saveButtonType) {
            int streetNumber;
        try {
            streetNumber = Integer.parseInt(streetNumberField.getText());
        } catch (NumberFormatException e) {
            // Handle the case where street number isn't valid...
            streetNumber = 0; 
        }
         Customer_Address address = new Customer_Address(streetNumber, streetNameField.getText(), suburbField.getText(), postcodeField.getText());
        List<Supplement> selectedSupplements = new ArrayList<>(dialogSupplementsList.getSelectionModel().getSelectedItems());

        if ("Paying".equals(customerTypeBox.getValue())) {
            PaymentMethod paymentMethod = new PaymentMethod(PaymentMethod.MethodType.valueOf(paymentMethodBox.getValue()), cardNumberField.getText());
            PayingCustomer newCustomer = new PayingCustomer(nameField.getText(), emailField.getText(), paymentMethod, address);
            selectedSupplements.forEach(newCustomer::addSupplement);
            magazine.addCustomer(newCustomer); 
            return newCustomer;
        } else if ("Associate".equals(customerTypeBox.getValue())) {
            PayingCustomer selectedPayingCustomer = (PayingCustomer) payingCustomerBox.getValue();
            if (selectedPayingCustomer == null) {
                // Handling if No paying customer selected
                return null;
            }
            AssociateCustomer newCustomer = new AssociateCustomer(nameField.getText(), emailField.getText(), selectedPayingCustomer, address);
            selectedSupplements.forEach(newCustomer::addSupplement);
            selectedPayingCustomer.addAssociate(newCustomer);
             magazine.addCustomer(newCustomer);
            return newCustomer; 
        }
      
    }
    return null;
    
});
    
    
    

    Optional<Customer> result = dialog.showAndWait();
     result.ifPresent(customer -> {
   
     List<Supplement> selectedSupplements = new ArrayList<>(dialogSupplementsList.getSelectionModel().getSelectedItems());



     updateCustomerListView();
     customersList.getSelectionModel().select(customer);
 });
    
    
}


    private boolean validateInputs(TextField emailField, TextField streetNumberField) {
        String email = emailField.getText();
        String streetNumberInput = streetNumberField.getText();
        boolean valid = true;

        if (!email.contains("@")) {
            showAlert("Invalid Email", "Email must contain '@' symbol.");
            valid = false;
        }

        try {
            Integer.parseInt(streetNumberInput);
        } catch (NumberFormatException e) {
            showAlert("Invalid Street Number", "Street Number must be a valid number.");
            valid = false;
        }

        return valid;
    }


        private void showAlert(String title, String content) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(content);
            alert.showAndWait();
        }

        private void updateCustomerListView() {
            ObservableList<Customer> customers = FXCollections.observableArrayList(magazine.getCustomers());
            customersList.setItems(customers);
            customersList.refresh();
        }

           @FXML
private void handleDeleteSupplement() {
    if (magazine.getSupplements().isEmpty()) {
        showAlert("Delete Supplement", "No supplements available to delete.");
        return;
    }

    // Creating a new dialog
    Dialog<Supplement> dialog = new Dialog<>();
    dialog.setTitle("Delete Supplement");
    dialog.setHeaderText("Select a supplement to delete:");

    ButtonType deleteButtonType = new ButtonType("Delete", ButtonBar.ButtonData.OK_DONE);
    dialog.getDialogPane().getButtonTypes().addAll(deleteButtonType, ButtonType.CANCEL);

    ListView<Supplement> supplementListView = new ListView<>();
    supplementListView.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
    supplementListView.setCellFactory(param -> new ListCell<Supplement>() {
        @Override
        protected void updateItem(Supplement item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty || item == null ? null : item.getName() + " - $" + item.getWeeklyCost());
        }
    });
    supplementListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

    // Adding the ListView to the dialog
    dialog.getDialogPane().setContent(supplementListView);

    // Converting the result to a Supplement when the delete button is clicked.
    dialog.setResultConverter(dialogButton -> {
        if (dialogButton == deleteButtonType) {
            return supplementListView.getSelectionModel().getSelectedItem();
        }
        return null;
    });

    Optional<Supplement> result = dialog.showAndWait();
    result.ifPresent(supplement -> {
        magazine.getSupplements().remove(supplement);
        supplementsList.getItems().remove(supplement); 

        // Remve the supplement from all customers subscriptions
        magazine.getCustomers().forEach(customer -> customer.getSupplementsList().remove(supplement));
        
        // Updating the list view for customers
        updateCustomerListView();
        
        showAlert("Supplement Deleted", "The supplement " + supplement.getName() + " has been successfully deleted and removed from all subscriptions.");
    });
}

        @FXML
      private void handleDeleteCustomer() {
          if (magazine.getCustomers().isEmpty()) {
              showAlert("Delete Customer", "No customers available to delete.");
              return;
          }

          Dialog<Customer> dialog = new Dialog<>();
          dialog.setTitle("Delete Customer");
          dialog.setHeaderText("Select a customer to delete:");
          ButtonType deleteButtonType = new ButtonType("Delete", ButtonBar.ButtonData.OK_DONE);
          dialog.getDialogPane().getButtonTypes().addAll(deleteButtonType, ButtonType.CANCEL);

          ListView<Customer> customerListView = new ListView<>();
          customerListView.setItems(FXCollections.observableArrayList(magazine.getCustomers()));
          customerListView.setCellFactory(param -> new ListCell<Customer>() {
              @Override
              protected void updateItem(Customer item, boolean empty) {
                  super.updateItem(item, empty);
                  setText(empty || item == null ? null : item.getName());
              }
          });
          customerListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
          dialog.getDialogPane().setContent(customerListView);

          dialog.setResultConverter(dialogButton -> {
              if (dialogButton == deleteButtonType) {
                  return customerListView.getSelectionModel().getSelectedItem();
              }
              return null;
          });

          Optional<Customer> result = dialog.showAndWait();
          result.ifPresent(customer -> {
              // here im Checking if customer is an associate and remove from paying customer's list
              if (customer instanceof AssociateCustomer) {
                  PayingCustomer payingCustomer = ((AssociateCustomer) customer).getPayingCustomer();
                  payingCustomer.removeAssociate((AssociateCustomer) customer);
              }

              magazine.removeCustomer(customer);
              updateCustomerListView(); // Refreshing the list view to reflect the deletion
              showAlert("Customer Deleted", "The customer has been successfully deleted.");
          });
      }


        @FXML
     private void handleAddSupplement() {

         Dialog<Supplement> dialog = new Dialog<>();
         dialog.setTitle("Add New Supplement");
         dialog.setHeaderText("Enter the details of the new supplement:");


         ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
         dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

         
         GridPane grid = new GridPane();
         grid.setHgap(10);
         grid.setVgap(10);

         TextField nameField = new TextField();
         nameField.setPromptText("Supplement Name");

         TextField costField = new TextField();
         costField.setPromptText("Weekly Cost");

       
         grid.add(new Label("Name:"), 0, 0);
         grid.add(nameField, 1, 0);
         grid.add(new Label("Weekly Cost:"), 0, 1);
         grid.add(costField, 1, 1);

         dialog.getDialogPane().setContent(grid);

  
         Platform.runLater(nameField::requestFocus);

         // Converting the result to a supplement when the add button is clicked.
         dialog.setResultConverter(dialogButton -> {
             if (dialogButton == addButtonType) {
                 try {
                     String name = nameField.getText();
                     double weeklyCost = Double.parseDouble(costField.getText());
                     return new Supplement(name, weeklyCost);
                 } catch (NumberFormatException e) {
                     showAlert("Invalid Input", "Weekly cost must be a valid number.");
                     return null; // Return null is to prevent dialog from closing on invalid input
                 }
             }
             return null;
         });

        
         Optional<Supplement> result = dialog.showAndWait();
         result.ifPresent(supplement -> {
             magazine.addSupplement(supplement);
             supplementsList.getItems().add(supplement); 
             showAlert("Supplement Added", "The supplement has been successfully added.");
         });
     }

        @FXML
        private void handleCreateAction() {

            // Step 1 here is to show dialog for Magazine creation
            Optional<Magazine> newMagazine = showMagazineCreationDialog();
            newMagazine.ifPresent(magazine -> {
                this.magazine = magazine;
                // Step 2 is Once the magazine is created, user cann prooceed to add supplements
                showSupplementCreationDialog(magazine);
                // and at Step 3 After adding supplements, user can proceed to add customers
                showCustomerCreationDialog(magazine);
                // Updating the view to reflect the new additions
                updateViewWithNewMagazine(magazine);
            });
        }




        private Optional<Magazine> showMagazineCreationDialog() {
        
            Dialog<Magazine> dialog = new Dialog<>();
            dialog.setTitle("Create New Magazine");
            dialog.setHeaderText("Enter magazine details");

          
            ButtonType createButtonType = new ButtonType("Create", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().addAll(createButtonType, ButtonType.CANCEL);

          
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField magazineNameField = new TextField();
            magazineNameField.setPromptText("Magazine Name");

            TextArea magazineDescField = new TextArea();
            magazineDescField.setPromptText("Description");
            magazineDescField.setPrefHeight(100); // Makes the TextArea a bit bigger

            grid.add(new Label("Name:"), 0, 0);
            grid.add(magazineNameField, 1, 0);
            grid.add(new Label("Description:"), 0, 1);
            grid.add(magazineDescField, 1, 1);

            dialog.getDialogPane().setContent(grid);

        
            Platform.runLater(magazineNameField::requestFocus);

            // Convert the result to a Magazine when the create button is clicked
            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == createButtonType) {
                    String name = magazineNameField.getText().trim();
                    String description = magazineDescField.getText().trim();
               
                    if (!name.isEmpty()) {
                   
                        return new Magazine(name, description);
                    }
                }
                return null;
            });

          
            Optional<Magazine> result = dialog.showAndWait();
            result.ifPresent(magazine -> {
                System.out.println("Magazine Created: " + magazine.getName());
            
            });

            return result;
        }

        private void showSupplementCreationDialog(Magazine magazine) {
            // Creating a custom dialog
            Dialog<Supplement> dialog = new Dialog<>();
            dialog.setTitle("Add New Supplement");
            dialog.setHeaderText("Enter details for the new supplement:");

          
            ButtonType addButtonType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

            // Creating fields for user input
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField supplementNameField = new TextField();
            supplementNameField.setPromptText("Supplement Name");

            TextField weeklyCostField = new TextField();
            weeklyCostField.setPromptText("Weekly Cost");

            grid.add(new Label("Name:"), 0, 0);
            grid.add(supplementNameField, 1, 0);
            grid.add(new Label("Weekly Cost:"), 0, 1);
            grid.add(weeklyCostField, 1, 1);

            dialog.getDialogPane().setContent(grid);

    
            Platform.runLater(supplementNameField::requestFocus);

         
            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == addButtonType) {
                    String name = supplementNameField.getText().trim();
                    double weeklyCost = 0;
                    try {
                        weeklyCost = Double.parseDouble(weeklyCostField.getText().trim());
                    
                        return new Supplement(name, weeklyCost);
                    } catch (NumberFormatException e) {
                        // Handling invalid number input
                        showAlert("Invalid Input", "Weekly cost must be a valid number.");
                        return null; // Returning null to prevent the dialog from closing on invalid input
                    }
                }
                return null;
            });

           
            Optional<Supplement> result = dialog.showAndWait();
            result.ifPresent(supplement -> {
                magazine.addSupplement(supplement); 
               
                System.out.println("Supplement Added: " + supplement.getName() + ", Cost: $" + supplement.getWeeklyCost());
            });
        }





        private void showCustomerCreationDialog(Magazine magazine) {
             ListView<Supplement> dialogSupplementsList = new ListView<>();
        dialogSupplementsList.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
        dialogSupplementsList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        dialogSupplementsList.setPrefHeight(50);

        dialogSupplementsList.setCellFactory(lv -> new ListCell<Supplement>() {
            @Override
            protected void updateItem(Supplement item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getName());
            }
        });

        // here I Assuming that magazine.getCustomers() returns an ObservableList
        ObservableList<Customer> payingCustomers = magazine.getCustomers().stream()
            .filter(c -> c instanceof PayingCustomer)
            .collect(Collectors.toCollection(FXCollections::observableArrayList));

        ComboBox<Customer> payingCustomerBox = new ComboBox<>(payingCustomers);
        payingCustomerBox.setConverter(new StringConverter<Customer>() {
            @Override
            public String toString(Customer customer) {
                return customer != null ? customer.getName() : "";
            }

            @Override
            public Customer fromString(String string) {
                return null; 
            }
        });
            payingCustomerBox.setDisable(true); 


            Dialog<Customer> dialog = new Dialog<>();
            dialog.setTitle("Add New Customer");
            dialog.setHeaderText("Fill in the details for the new customer:");


            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField nameField = new TextField();
            nameField.setPromptText("Name");

            TextField emailField = new TextField();
            emailField.setPromptText("Email");

            TextField streetNameField = new TextField();
            streetNameField.setPromptText("Street Name");

            TextField streetNumberField = new TextField();
            streetNumberField.setPromptText("Street Number");

            TextField suburbField = new TextField();
            suburbField.setPromptText("Suburb");

            TextField postcodeField = new TextField();
            postcodeField.setPromptText("Postcode");

            ComboBox<String> customerTypeBox = new ComboBox<>();
            customerTypeBox.getItems().addAll("Paying", "Associate");

            ComboBox<String> paymentMethodBox = new ComboBox<>();
            grid.add(new Label("Paying Customer:"), 0, 11); 
            grid.add(payingCustomerBox, 1, 11);
            paymentMethodBox.getItems().addAll("CREDIT_CARD", "DIRECT_DEBIT");
            paymentMethodBox.setDisable(true);
            TextField cardNumberField = new TextField();
            cardNumberField.setPromptText("Card Number");
            cardNumberField.setDisable(true);
            ListView<Supplement> supplementsListView = new ListView<>();
            supplementsListView.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
            supplementsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            ComboBox<PayingCustomer> payingCustomersBox = new ComboBox<>();
            payingCustomersBox.getItems().addAll(magazine.getPayingCustomers()); // Here I just implemented getPayingCustomers() to return only paying customers (DON'T FORGET)
            payingCustomersBox.setDisable(true); 



       /// enabling this box only for associate customers
        customerTypeBox.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean isAssociate = "Associate".equals(newVal);
            payingCustomersBox.setDisable(!isAssociate);
        });

    
    customerTypeBox.valueProperty().addListener((obs, oldVal, newVal) -> {
    boolean isPaying = "Paying".equals(newVal);
    paymentMethodBox.setDisable(!isPaying);
    cardNumberField.setDisable(!isPaying);
    payingCustomerBox.setDisable(!"Associate".equals(newVal)); 
});


   
    grid.add(new Label("Name:"), 0, 0);
    grid.add(nameField, 1, 0);
    grid.add(new Label("Email:"), 0, 1);
    grid.add(emailField, 1, 1);
    grid.add(new Label("Street Name:"), 0, 2);
    grid.add(streetNameField, 1, 2);
    grid.add(new Label("Street Number:"), 0, 3);
    grid.add(streetNumberField, 1, 3);
    grid.add(new Label("Suburb:"), 0, 4);
    grid.add(suburbField, 1, 4);
    grid.add(new Label("Postcode:"), 0, 5);
    grid.add(postcodeField, 1, 5);
    grid.add(new Label("Customer Type:"), 0, 6);
    grid.add(customerTypeBox, 1, 6);
    grid.add(new Label("Payment Method:"), 0, 7);
    grid.add(paymentMethodBox, 1, 7);
    grid.add(new Label("Card Number:"), 0, 8);
    grid.add(cardNumberField, 1, 8);
    grid.add(new Label("Supplements:"), 0, 10); 
    grid.add(dialogSupplementsList, 1, 10); 

    
       ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
    dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
    
    
    Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
    saveButton.addEventFilter(ActionEvent.ACTION, event -> {
    if (!validateInputs(emailField, streetNumberField)) { 
        event.consume(); // Preventing the dialog from closing
    }
});

    dialog.getDialogPane().setContent(grid);
    Platform.runLater(nameField::requestFocus);
    
    

    dialog.setResultConverter(dialogButton -> {
       
        
    
        if (dialogButton == saveButtonType) {
            int streetNumber;
        try {
            streetNumber = Integer.parseInt(streetNumberField.getText());
        } catch (NumberFormatException e) {
            // Handle the case where street number isn't valid
            streetNumber = 0; 
        }
         Customer_Address address = new Customer_Address(streetNumber, streetNameField.getText(), suburbField.getText(), postcodeField.getText());
        List<Supplement> selectedSupplements = new ArrayList<>(dialogSupplementsList.getSelectionModel().getSelectedItems());

        if ("Paying".equals(customerTypeBox.getValue())) {
            PaymentMethod paymentMethod = new PaymentMethod(PaymentMethod.MethodType.valueOf(paymentMethodBox.getValue()), cardNumberField.getText());
            PayingCustomer newCustomer = new PayingCustomer(nameField.getText(), emailField.getText(), paymentMethod, address);
            selectedSupplements.forEach(newCustomer::addSupplement);
            magazine.addCustomer(newCustomer); 
            return newCustomer;
        } else if ("Associate".equals(customerTypeBox.getValue())) {
            PayingCustomer selectedPayingCustomer = (PayingCustomer) payingCustomerBox.getValue(); 
            if (selectedPayingCustomer == null) {
                // Handle error if no paying customer selected 
                return null;
            }
            AssociateCustomer newCustomer = new AssociateCustomer(nameField.getText(), emailField.getText(), selectedPayingCustomer, address);
            selectedSupplements.forEach(newCustomer::addSupplement);
            selectedPayingCustomer.addAssociate(newCustomer);
             magazine.addCustomer(newCustomer);
            return newCustomer; 
        }
      
    }
    return null;
    
});
    
    
    // Showing the dialog and waiting for the user to input the details
    Optional<Customer> result = dialog.showAndWait();
result.ifPresent(customer -> {
    updateCustomerListView();
    customersList.getSelectionModel().select(customer);
    updateViewWithNewMagazine(this.magazine); // Refreshing the UI with the updated magazine
});

}

private void updateViewWithNewMagazine(Magazine magazine) {
    // Updating supplementslist
    supplementsList.getItems().clear();
    supplementsList.getItems().addAll(FXCollections.observableArrayList(magazine.getSupplements()));

    // Update customerslist
    customersList.getItems().clear();
    customersList.getItems().addAll(FXCollections.observableArrayList(magazine.getCustomers()));

    // Update details
    infoPanel.setText(getMagazineDetails(magazine));
}



private String getMagazineDetails(Magazine magazine) {
    StringBuilder details = new StringBuilder("Magazine Details:\n");
    details.append("Name: ").append(magazine.getName()).append("\n");
    details.append("Supplements:\n");
    for (Supplement supplement : magazine.getSupplements()) {
        details.append(" - ").append(supplement.getName())
               .append(": $").append(supplement.getWeeklyCost()).append("/week\n");
    }
    details.append("Customers:\n");
    for (Customer customer : magazine.getCustomers()) {
        details.append(" - ").append(customer.getName())
               .append(" (").append(customer.getClass().getSimpleName()).append(")\n");
    }
    return details.toString();
}






    public void postInitialization() {
        editInfoButton.setDisable(true); 
        // Directly setting items for customersList
        customersList.setItems(FXCollections.observableArrayList(magazine.getCustomers()));
        customersList.setCellFactory(param -> new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName());
            }
        });
        customersList.setCellFactory(listView -> new ListCell<Customer>() {
    @Override
    protected void updateItem(Customer customer, boolean empty) {
        super.updateItem(customer, empty);
        if (empty || customer == null) {
            setText(null);
        } else {
            String text = customer.getName() + " - Subscriptions: ";
            text += customer.getSupplementsList().stream()
                    .map(Supplement::getName)
                    .collect(Collectors.joining(", "));
            setText(text);
        }
    }
});
        supplementsList.setItems(FXCollections.observableArrayList(magazine.getSupplements()));
        supplementsList.setCellFactory(param -> new ListCell<Supplement>() {
            @Override
            protected void updateItem(Supplement item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName());
            }
        });
        
     
        customersList.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            selectedCustomer = newSelection;
            updateInfoPanelForSelectedCustomer(newSelection);
            billingInfoButton.setDisable(!(newSelection instanceof PayingCustomer));
        });
        
            setupSupplementsListListener();
    setupCustomersListListener();
    }
    
       private void updateInfoPanelForSelectedCustomer(Customer customer) {
           
           if (customer == null) {
        infoPanel.setText(""); 
        return; // Exit the method early as there's no customer to display
    }
           
    StringBuilder info = new StringBuilder();
    info.append("Name: ").append(customer.getName()).append("\n")
        .append("Email: ").append(customer.getEmail()).append("\n")
        .append("Address: ").append(customer.getAddress().toString()).append("\n") // Make sure Customer_Address toString() is overridden to format the address nicely
        .append("Subscriptions:\n");

    for (Supplement supplement : customer.getSupplementsList()) {
        info.append("\t- ").append(supplement.getName()).append(": $").append(supplement.getWeeklyCost()).append("\n");
    }

    if (customer instanceof PayingCustomer) {
        PayingCustomer payingCustomer = (PayingCustomer) customer;
        info.append("Status: Paying Customer\n");
        info.append("Payment Method: ").append(payingCustomer.getPaymentMethod().toString()).append("\n");

        if (!payingCustomer.getAssociateCustomers().isEmpty()) {
            info.append("Associate Customers:\n");
            for (Customer associate : payingCustomer.getAssociateCustomers()) {
                info.append("\t- ").append(associate.getName()).append("\n");
            }
        }
    } else {
        info.append("Status: Associate Customer\n");
    }

    infoPanel.setText(info.toString());
}

     @FXML
    private void handleBillingInfoAction() {
        if (selectedCustomer instanceof PayingCustomer) {
            fetchAndDisplayBillingHistoryAsync((PayingCustomer) selectedCustomer);
        }
    }
    
private void setupCustomersListListener() {
    customersList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        selectedCustomer = newValue; 
        if (newValue != null) {
            updateInfoPanelForSelectedCustomer(newValue);
            editInfoButton.setDisable(false);
            billingInfoButton.setDisable(!(newValue instanceof PayingCustomer));
        } else {
            editInfoButton.setDisable(true); // Disabling the edit button if no customer is selected
        }
    });
}

    private void fetchAndDisplayBillingHistoryAsync(PayingCustomer payingCustomer) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            String billingHistory = payingCustomer.getMonthlyChargesEmailText();
            Platform.runLater(() -> infoPanel.appendText("\nBilling History:\n" + billingHistory));
        });
        executor.shutdown();
    }
    
    private void setupSupplementsListListener() {
    supplementsList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue != null) {
            updateInfoPanelForSelectedSupplement(newValue);
        }
    });
}
        
    private void updateInfoPanelForSelectedSupplement(Supplement selectedSupplement) {
    StringBuilder info = new StringBuilder();
    info.append("Supplement Name: ").append(selectedSupplement.getName()).append("\n")
        .append("Weekly Cost: $").append(selectedSupplement.getWeeklyCost()).append("\n")
        .append("Subscribed Customers:\n");

    for (Customer customer : magazine.getCustomers()) {
        if (customer.getSupplementsList().contains(selectedSupplement)) {
            info.append(customer.getName()).append("\n");
        }
    }

    infoPanel.setText(info.toString());
}
   
}