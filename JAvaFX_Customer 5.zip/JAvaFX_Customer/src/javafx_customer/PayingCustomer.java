package javafx_customer;

import java.util.ArrayList;
import java.util.List;

public class PayingCustomer extends Customer {
    private PaymentMethod paymentMethod;
    private List<Customer> associateCustomers;
    

    public PayingCustomer(String name, String email, PaymentMethod paymentMethod, Customer_Address address) {
        super(name, email, address);
        this.paymentMethod = paymentMethod;
        this.associateCustomers = new ArrayList<>();
    }

    public void addAssociate(Customer associate) {
        if (!associateCustomers.contains(associate)) {
            associateCustomers.add(associate);
        }
    }

    public void removeAssociate(Customer associate) {
        associateCustomers.remove(associate);
    }
    public void removeAssociate(AssociateCustomer associateCustomer) {
        this.associateCustomers.remove(associateCustomer);
    }
    //history
    public String fetchBillingHistory() {
        
        try {
            Thread.sleep(2000); 
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); 
            return "Failed to fetch billing history.";
        }
        // Return a simulated billing history
        return "January: $50\nFebruary: $45\nMarch: $55";
    }



    public String getMonthlyChargesEmailText() {
        StringBuilder emailText = new StringBuilder("Dear " + getName() + ",\nYour monthly magazine subscription charges:");
        double totalCost = 0;

        double selfCost = 0;
        for (Supplement supplement : getSupplementsList()) {
            selfCost += supplement.getWeeklyCost() * 4; 
        }
        emailText.append("\n\nYour subscription: ");
        for (Supplement supplement : getSupplementsList()) {
            emailText.append("\n- ").append(supplement.getName()).append(": $").append(supplement.getWeeklyCost() * 4);
        }
        emailText.append("\nTotal: $").append(selfCost);
        totalCost += selfCost;

        for (Customer associate : getAssociateCustomers()) {
            double associateCost = 0;
            for (Supplement supplement : associate.getSupplementsList()) {
                associateCost += supplement.getWeeklyCost() * 4;
            }
            emailText.append("\n\n").append(associate.getName()).append("'s subscription: ");
            for (Supplement supplement : associate.getSupplementsList()) {
                emailText.append("\n- ").append(supplement.getName()).append(": $").append(supplement.getWeeklyCost() * 4);
            }
            emailText.append("\nTotal: $").append(associateCost);
            totalCost += associateCost;
        }

        emailText.append("\n\nTotal Monthly Charge: $").append(totalCost);
        return emailText.toString();
    }

    // Getters and Setters
    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public List<Customer> getAssociateCustomers() {
        return associateCustomers;
    }
    // Setter for paymentMethod
    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
