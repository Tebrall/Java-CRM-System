package javafx_customer;

public class Supplement {
    private String name;
    private double weeklyCost;

    public Supplement(String name, double weeklyCost) {
        this.name = name;
        this.weeklyCost = weeklyCost;
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getWeeklyCost() {
        return weeklyCost;
    }

    public void setName(String newName) {
    }

    public void setWeeklyCost(double newCost) {
    }
    
    public String toString(){
        return name;
    }
}

