package javafx_customer;

/**
 Created by Teimur Bairamaliev;
 Student ID 34684126;
 Date: 3.04.2024;
 JAVA FILE's included in this project:
 *MainViewController.java
 *Customer.java
 *PayingCustomer.java
 *AssociateCustomer.java
 *Supplement.java
 *PaymentMethod.java
 *Customer_Address.java
 *MagazineServiceApp.java
 *Magazine.java
 DESCRIPTION OF THE  PROJECT:
 "a program to manage an online weekly personalized magazine service.";
 */


import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class MagazineServiceApp extends Application {

@Override
public void start(Stage primaryStage) throws Exception {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafx_customer/MainView.fxml"));
    Parent root = loader.load();
    MainViewController controller = loader.getController();
Scene scene = new Scene(root, 800, 600);

URL cssURL = getClass().getResource("/javafx_customer/mainview.css");
    if (cssURL != null) {
        String css = cssURL.toExternalForm();
        scene.getStylesheets().add(css);
    } else {
        System.err.println("Failed to load CSS file.");
    }

    Magazine magazine = new Magazine(1); 
    setupPredefinedData(magazine); 
    controller.setMagazine(magazine); 

    controller.postInitialization(); 

    primaryStage.setTitle("Magazine Service Application");
    primaryStage.setScene(scene);
    primaryStage.show();
}




private void setupPredefinedData(Magazine magazine) {
    
    magazine.addSupplement(new Supplement("Luxury Homes", 5));
    magazine.addSupplement(new Supplement("Exotic Cars", 3));
    magazine.addSupplement(new Supplement("Jewelry Queen", 4));

  
    Customer_Address address1 = new Customer_Address(123, "Main Street", "Suburbia", "12345");
    Customer_Address address2 = new Customer_Address(456, "Second Street", "Downtown", "67890");
    Customer_Address address3 = new Customer_Address(789, "Third Avenue", "Uptown", "10112");

    PayingCustomer payingCustomer1 = new PayingCustomer("Kamran", "Kamran@gmail.com", new PaymentMethod(PaymentMethod.MethodType.CREDIT_CARD, "1234-5678-9012-3456"), address1);
    payingCustomer1.addSupplement(magazine.getSupplements().get(0));

    AssociateCustomer associateCustomer1 = new AssociateCustomer("Jaman", "Jaman@outlook.com", payingCustomer1, address3);
    associateCustomer1.addSupplement(magazine.getSupplements().get(1));

    PayingCustomer payingCustomer2 = new PayingCustomer("Emin", "Emin777@mail.ru", new PaymentMethod(PaymentMethod.MethodType.DIRECT_DEBIT, "9876-5432-1098-7654"), address2);
    payingCustomer2.addSupplement(magazine.getSupplements().get(2));

    magazine.addCustomer(payingCustomer1);
    magazine.addCustomer(associateCustomer1);
    magazine.addCustomer(payingCustomer2);
}


    public static void main(String[] args) {
        launch(args);
        
    }
}