package javafx_customer;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Magazine {
    private double weeklyCost;
    private List<Supplement> supplements;
    private List<Customer> customers;
    private String name;
    private String description;
  

    // Constructor
    public Magazine(String name, String description) {
        this.name = name;
        this.description = description;
        this.supplements = new ArrayList<>();
        this.customers = new ArrayList<>();
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Magazine(double weeklyCost) {
        this.weeklyCost = weeklyCost;
        this.supplements = new ArrayList<>();
        this.customers = new ArrayList<>();
    }

    

    public void addSupplement(Supplement supplement) {
        supplements.add(supplement);
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void removeCustomer(Customer customer) {
        customers.remove(customer);
    }
  

    // Getters and Setters
    public double getWeeklyCost() {
        return weeklyCost;
    }

    public List<Supplement> getSupplements() {
        return supplements;
    }

    public List<Customer> getCustomers() {
        return customers;
    }
    public List<PayingCustomer> getPayingCustomers() {
    return customers.stream()
            .filter(PayingCustomer.class::isInstance)
            .map(PayingCustomer.class::cast)
            .collect(Collectors.toList());
}

    

}


