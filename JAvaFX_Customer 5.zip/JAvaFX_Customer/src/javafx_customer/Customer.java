package javafx_customer;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private String email;
    private List<Supplement> supplementsList;
    private boolean isUserAdded;
     private Customer_Address address;

    public Customer(String name, String email,Customer_Address address) {
        this.name = name;
        this.email = email;
        this.supplementsList = new ArrayList<>();
        this.isUserAdded = false; // Default value
        this.address = address;
        
    }

    public void addSupplement(Supplement supplement) {
        supplementsList.add(supplement);
    }

    public void removeSupplement(Supplement supplement) {
        supplementsList.remove(supplement);
    }
    public Customer_Address getAddress() {
        return address;
    }
    // Generating and return the  email text
    public String getEmailText() {
        StringBuilder emailText = new StringBuilder("Dear " + name + ",\nYour weekly magazine is ready. This week includes: ");
        for (Supplement supplement : supplementsList) {
            emailText.append("\n- ").append(supplement.getName()).append(": $").append(supplement.getWeeklyCost());
        }
        return emailText.toString();
    }


    // Getters and Setters
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public List<Supplement> getSupplementsList() {
        return supplementsList;
    }
    public boolean isUserAdded() {
        return this.isUserAdded;
    }

    public void setUserAdded(boolean isUserAdded) {
        this.isUserAdded = isUserAdded;
    }
    public void setAddress(Customer_Address address) {
        this.address = address;
    }
    
      public void setName(String name) {
        this.name = name;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }
}

