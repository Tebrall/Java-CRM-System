package javafx_customer;

public class PaymentMethod {
  

 
    public PaymentMethod(MethodType methodType, String details) {
    this.methodType = methodType;
    this.details = details;
}


    public enum MethodType {
        CREDIT_CARD, DIRECT_DEBIT;

        static MethodType valueOf(MethodType value) {
            throw new UnsupportedOperationException("Not supported yet."); 
        }
    }

    private MethodType methodType;
    private String details; 

    // Constructor, getters, and setters 


   @Override
public String toString() {
    String methodTypeStr = (methodType != null) ? methodType.toString() : "Unknown";
    String detailDisplay = "Unavailable";
    if (details != null && !details.isEmpty()) {
        int length = details.length();
        detailDisplay = (length > 4) ? "ending in " + details.substring(length - 4) : details;
    }
    return methodTypeStr + " " + detailDisplay;
}
   // Getter for methodType
    public MethodType getMethodType() {
        return methodType;
    }

    // Getter for details
    public String getDetails() {
        return details;
    }

}



