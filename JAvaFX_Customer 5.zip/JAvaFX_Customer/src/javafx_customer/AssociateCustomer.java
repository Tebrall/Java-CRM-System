package javafx_customer;
public class AssociateCustomer extends Customer {
    private PayingCustomer payingCustomer;
    

  

    public PayingCustomer getPayingCustomer() {
        return this.payingCustomer;
    }

    public AssociateCustomer(String name, String email, PayingCustomer payingCustomer, Customer_Address address) {
        super(name, email, address);
        this.payingCustomer = payingCustomer;
        this.payingCustomer.addAssociate(this);
    }

}
